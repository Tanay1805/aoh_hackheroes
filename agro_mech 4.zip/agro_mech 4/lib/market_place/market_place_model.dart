import '/flutter_flow/flutter_flow_util.dart';
import 'market_place_widget.dart' show MarketPlaceWidget;
import 'package:flutter/material.dart';

class MarketPlaceModel extends FlutterFlowModel<MarketPlaceWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
