import '/flutter_flow/flutter_flow_util.dart';
import 'product1_copy2_copy2_copy_widget.dart'
    show Product1Copy2Copy2CopyWidget;
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class Product1Copy2Copy2CopyModel
    extends FlutterFlowModel<Product1Copy2Copy2CopyWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Carousel widget.
  CarouselController? carouselController;

  int carouselCurrentIndex = 1;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
