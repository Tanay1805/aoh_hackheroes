import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MarketPlaceRecord extends FirestoreRecord {
  MarketPlaceRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "product_name" field.
  String? _productName;
  String get productName => _productName ?? '';
  bool hasProductName() => _productName != null;

  // "product_description" field.
  String? _productDescription;
  String get productDescription => _productDescription ?? '';
  bool hasProductDescription() => _productDescription != null;

  // "price" field.
  int? _price;
  int get price => _price ?? 0;
  bool hasPrice() => _price != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  void _initializeFields() {
    _productName = snapshotData['product_name'] as String?;
    _productDescription = snapshotData['product_description'] as String?;
    _price = castToType<int>(snapshotData['price']);
    _image = snapshotData['image'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('MarketPlace');

  static Stream<MarketPlaceRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MarketPlaceRecord.fromSnapshot(s));

  static Future<MarketPlaceRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MarketPlaceRecord.fromSnapshot(s));

  static MarketPlaceRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MarketPlaceRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MarketPlaceRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MarketPlaceRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MarketPlaceRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MarketPlaceRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMarketPlaceRecordData({
  String? productName,
  String? productDescription,
  int? price,
  String? image,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'product_name': productName,
      'product_description': productDescription,
      'price': price,
      'image': image,
    }.withoutNulls,
  );

  return firestoreData;
}

class MarketPlaceRecordDocumentEquality implements Equality<MarketPlaceRecord> {
  const MarketPlaceRecordDocumentEquality();

  @override
  bool equals(MarketPlaceRecord? e1, MarketPlaceRecord? e2) {
    return e1?.productName == e2?.productName &&
        e1?.productDescription == e2?.productDescription &&
        e1?.price == e2?.price &&
        e1?.image == e2?.image;
  }

  @override
  int hash(MarketPlaceRecord? e) => const ListEquality()
      .hash([e?.productName, e?.productDescription, e?.price, e?.image]);

  @override
  bool isValidKey(Object? o) => o is MarketPlaceRecord;
}
