import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyCWz8zGZExb_YEWpMcBWi3KqSMhWyEn07s",
            authDomain: "agromech-5f498.firebaseapp.com",
            projectId: "agromech-5f498",
            storageBucket: "agromech-5f498.appspot.com",
            messagingSenderId: "820454614833",
            appId: "1:820454614833:web:7cf1715a3f36860b05b210",
            measurementId: "G-HRGSC00YV9"));
  } else {
    await Firebase.initializeApp();
  }
}
