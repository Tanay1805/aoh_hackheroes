import '/flutter_flow/flutter_flow_util.dart';
import 'drip_select_widget.dart' show DripSelectWidget;
import 'package:flutter/material.dart';

class DripSelectModel extends FlutterFlowModel<DripSelectWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
